import * as anchor from "@project-serum/anchor";
export var USDC_PUBKEY = new anchor.web3.PublicKey("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v");
export var WSOL_PUBKEY = new anchor.web3.PublicKey("So11111111111111111111111111111111111111112");
export var BONK_PUBKEY = new anchor.web3.PublicKey("DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263");
export var SAMO_PUBKEY = new anchor.web3.PublicKey("7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU");
export var SPL_ASSOCIATED_TOKEN_ACCOUNT_PROGRAM_ID = new anchor.web3.PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL");
//# sourceMappingURL=pubkeys.config.js.map