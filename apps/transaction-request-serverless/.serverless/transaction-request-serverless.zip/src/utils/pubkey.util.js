import { web3 } from "@project-serum/anchor";
export var pubkeyOrThrow = function (input) {
    try {
        return new web3.PublicKey(input);
    }
    catch (_a) {
        throw new Error("Could not create a public key with the provided input.");
    }
};
//# sourceMappingURL=pubkey.util.js.map