export var createJupiterQuoteRequestUrl = function (quantity, fromMint, toMint) {
    var jupiterQuoteUrl = "https://quote-api.jup.ag/v4/quote?inputMint=".concat(fromMint, "&outputMint=").concat(toMint, "&amount=").concat(quantity, "&slippageBps=1&swapMode=ExactOut");
    return jupiterQuoteUrl;
};
//# sourceMappingURL=jupiter.util.js.map