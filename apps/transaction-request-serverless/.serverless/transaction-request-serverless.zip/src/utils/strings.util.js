import { z } from 'zod';
export var stringifiedNumberSchema = function () {
    return z
        .string()
        .transform(parseFloat)
        .refine(function (value) { return !isNaN(value) && isFinite(value); }, {
        message: 'Input must be a valid number in string format',
    });
};
//# sourceMappingURL=strings.util.js.map